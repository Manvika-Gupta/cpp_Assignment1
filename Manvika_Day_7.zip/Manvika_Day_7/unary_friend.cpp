//to demonstrate friend function with unary opeator.
#include<iostream>
using namespace std;
class space{
    
    public:
    
    int a,b,c;
    space(int x=0, int y =0, int z=0){
        a = x;
        b = y;
        c = z;
    }
    void display(){
        cout<<"\nx="<<a<<" y="<<b<<" z="<<c<<endl;
    }
    void friend operator++(space &value);//for pre increment
   // void friend operator++(space &val);//for post increment  //error
    void friend operator--(space &value);//for pre decrement
    //void friend operator--(space &val);//for post decrement  //error
    void friend operator-(space &value);
    
};

void operator ++(space &val)
{
cout<<"Pre increment!";
++val.a;
++val.b;
++val.c;

}

/*
void operator ++(space &val)
{
cout<<"Post increment!\n";

val.a++;
val.b++;
val.c++;

}*/ //error


void operator --(space &val)
{
cout<<"Pre decrement!";

--val.a;
--val.b;
--val.c;

}

void operator -(space &val)
{
cout<<"Unary Negate!";

val.a=-val.a;
val.b=-val.b;
val.c=-val.c;

}


int main(){
space q1(5,5,5);

q1.display();
++q1;
q1.display();
space q3(5,5,5);
q3.display();
--q3;
q3.display();

space q2(5,5,5);
q2.display();
-q2;
q2.display();


return 0;
}
