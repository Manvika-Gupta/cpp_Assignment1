//this demo includes operator overloading of unary operators
#include<iostream>
using namespace std;

class space
{
public:
int x,y,z;
	space()
	{
	x=y=z=0;
	}

	space(int a,int b,int c)
	{
		x=a;
		y=b;
		z=c;
		
	}
	
	void show()
		{
		cout<<"x="<<x<<" y="<<y<<" z="<<z<<endl;
		}
	void operator-();
	//void operator--();
	void operator++(int);
        void operator++();
	void operator--();
	void operator--(int);
};

void space::operator-()
{
	x=-x;
	y=-y;
	z=-z;
}

void space::operator++() //pre
{
	++x;
	++y;
	++z;
cout<<"Pre increment----------x="<<x<<endl;

}

void space::operator++(int)
{
//space temp;
//temp.x=
x++;
//temp.y=
y++;
//temp.z=
z++;
//return temp;
	
cout<<"Post increment"<<endl;
}
void space::operator--()
{
	--x;
	--y;
	--z;
cout<<"Pre decrement"<<endl;

}
void space::operator--(int)
{
	x--;
	y--;
	z--;
cout<<"Post decrement"<<endl;

}





int main()
{

cout<<"\nusing - unary operator\n"<<endl;	
	space s1(5,4,3);
	s1.show();
	-s1;
	s1.show();
	
	cout<<"\nNOW using -- (post) unary operator\n"<<endl;
	space s2(5,4,3);
	s2.show();
	s2--;
	s2.show();
	cout<<endl;
	
	cout<<"\nNOW using -- (pre) unary operator\n"<<endl;
	space s5(1,2,3);
	s5.show();
	--s5;
	s5.show();
	cout<<endl;

	cout<<"\nNOW using ++ (post) unary operator\n"<<endl;
	space s3(5,4,3), d;
	s3.show();
	s3++;

	s3.show();
	cout<<"\nNOW using ++ (pre) unary operator\n"<<endl;
	space s4(1,2,3);
	s4.show();
	++s4;
	s4.show();
	cout<<endl;

	
return 0;
}
