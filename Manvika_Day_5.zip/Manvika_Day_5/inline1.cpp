//demo to show inline function
#include<iostream>
using namespace std;

int cube(int);

int main()
{

int n;
cout<<"Enter number ";
cin>>n;
int ans=cube(n);
cout<<"Cube is "<<ans;

return 0;
}

inline int cube(int n)
{
int cube = n * n * n;
return cube;
}
