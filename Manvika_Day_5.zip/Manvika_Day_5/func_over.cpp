//To demo. function overloading

#include<iostream>
using namespace std;
float sum(int);
void sum(int, float);
float sum(int, int, float);

/*
class sum
{

	int sum(int a, float b)
	{
		return a+b;
	}

	int sum(int a, int b , int c)
	{
		return a+b+c;
	}


};
*/

int main()
{

cout<<"Sum of 5 is "<<sum(5)<<endl;
cout<<"Sum of 5 and 5 is ";sum(5,5);
cout<<"Sum of 5, 5 and 5.5 is "<<sum(5,5,5.5)<<endl;

return 0;
}

//arguments make the function unique
void sum(int a,float b)
{

	float sum=a+b;
	cout<<sum<<endl;
}

  
float sum(int a,int b,float c)
{

	return a+b+c; //implicit comversion of int to float will be done

}


float sum(int a) //implicit comversion of int to float will be done
{

	return a;

}
