//code to demonstrate default function arguments.
#include<iostream>
using namespace std;

int cubeVolume(int l, int w=10, int h=20) 
//assignment of arguments from right to left
{

	return (l*w*h); 

}

int main()
{

	cout <<"cube is :"<<cubeVolume(5)<<endl;//considers 5 10 20
	cout <<"cube is :"<<cubeVolume(5,5)<<endl;//considers 5 5 20
	cout <<"cube is :"<<cubeVolume(5,5,5)<<endl;//considers 5 5 5

return 0;
}
