#include <iostream>

using namespace std;


class measure{
    public:
        int h, l, w;
        void setInput(int a, int b, int c){
            h = a;
            l = b;
            w = c; 
        }
        
        int area(){
            return w * l;
        }
        int volume(){
            return w * l * h;
        }
};
int main()
{
    measure obj1,obj2;
    
    obj1.setInput(10,12,15);
    cout<< "Area of object 1 is: "<<obj1.area();
    cout<< "\nvolume of object 1 is : "<<obj1.volume();
    
    obj2.setInput(12,13,22);
    cout<< "\nArea of object 2 is: "<<obj2.area();
    cout<< "\nvolume of object 2 is : "<<obj2.volume();

    return 0;
}

