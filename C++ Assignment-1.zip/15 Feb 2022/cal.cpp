
#include <iostream>

using namespace std;

class Calculator{
    public:
        int input1;
        int input2;
        
        void setInput(int a, int b){
            input1 = a;
            input2 = b;
        }
        int add(){
            return input1+input2;
        }
        float sub(){
            return input1-input2;
        }
        int mul(){
            return input1*input2;
        }
       int division(Calculator,Calculator);
       int modulus(Calculator,Calculator);
        
};

 int Calculator :: division(Calculator x,Calculator y){
       
            return x.input1/y.input1;
}

int Calculator :: modulus(Calculator x,Calculator y){
       
            return x.input1%y.input1;
}


int main()
{
    Calculator obj1,obj2,obj4;
    int num1,num2;
    int op;
        
    cout<<"Enter Num1 & Num2: \n";
    cin>>num1>>num2;
    cout << "What do you want to do:\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Modulus\n";
    cin >> op;

    obj1.setInput(num1,num2);
    obj2.setInput(num1,num2);
    switch(op){
        case 1:
        
        cout<< "The inputs: "<<obj1.input1 <<" + "<< obj1.input2;
        cout<< "\nThe addition is: "<<obj1.add();
        break;
        
        case 2:
        cout<< "The inputs: "<<obj1.input1 <<" - "<< obj1.input2;
        cout<< "\nThe subtraction is: "<<obj1.sub();
        break;
        
        case 3:
        cout<< "The inputs: "<<obj1.input1 <<" * "<< obj1.input2;
        cout<< "\nThe multiplication is: "<<obj1.mul();
        break;
        
        case 4:
        cout<< "The inputs: "<<obj1.input1 <<" / "<< obj1.input2;	
        cout<< "\nThe division is: "<< obj1.division(obj1, obj2);
        break;
        
	case 5:
        cout<< "The inputs: "<<obj1.input1 <<" % "<< obj1.input2;	
        cout<< "\nThe modulus is: "<< obj1.division(obj1, obj2);
        break;

        default:
        cout<< "Invalid choice\n";
        break;
    }
    
    return 0;
}

