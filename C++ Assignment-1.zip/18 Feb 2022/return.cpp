//to demonstrate return by reference.
#include<iostream>
using namespace std;
int& max(int &, int &);
int main()
{

	int a,b,ans;
 	cout<<"Enter 2 numbers: \n";
	cin>>a>>b;		
	ans=max(a,b);
	cout<<"Maximum is "<<ans;

return 0;
}

int& max(int &x,int &y)
{


	if(x>y)
	//return x+1;
	return x;

	else 
	//return y+1;
	return y;

}

