//To demo. references and pointers for swapping 2 numbers.
#include<iostream>

using namespace std;

void swap_ref(int &x, int &y)
{
int temp;
temp=x;
x=y;
y=temp;

}

void swap_poin(int *x,int *y)
{
int temp;
temp=*x;
*x=*y;
*y=temp;

}





int main()
{
int n1=5,n2=3;
int n3=8,n4=9;

cout<<"Before swapping: "<< n1 <<" "<< n2 <<endl<<endl;
swap_ref(n1,n2);
cout<<"Using References"<<endl;
cout<<"After swapping: "<< n1 <<" "<< n2 <<endl<<endl;
cout<<"Before swapping: "<< n3 <<" "<< n4 <<endl<<endl;
swap_poin(&n3,&n4);
cout<<"Using Pointers"<<endl;
cout<<"After swapping: "<< n3 <<" "<< n4 <<endl;

return 0;

}
