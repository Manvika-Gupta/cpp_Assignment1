//Demo to shoe operator overloading

#include<iostream>
using namespace std;

class Complex
{

	int real,img;
	public:
		Complex() //default constructor
		{
		real=0;
		img=0;		
		}
		
		//parameter constructor
		Complex(int x, int y)
		{
		real=x;
		img=y;
		
		}
		
		void display()
		{
		cout<<"the real part is "<<real<<" and img part is "<<img<<endl<<endl;
		}
		// overloading '+' operator here
		Complex operator + (Complex obj)
		{
			Complex temp;
			temp.real= real + obj.real;
			temp.img= img + obj.img;
			return temp;
		}

		// overloading '-' operator here
		Complex operator - (Complex obj)
		{
			Complex temp;
			temp.real= real - obj.real;
			temp.img= img - obj.img;
			return temp;
		}

		// overloading '*' operator here
		Complex operator * (Complex obj)
		{
			Complex temp;
			temp.real= real * obj.real;
			temp.img= img * obj.img;
			return temp;
		}

		// overloading '/' operator here
		Complex operator / (Complex obj)
		{
			Complex temp;
			temp.real= real / obj.real;
			temp.img= img / obj.img;
			return temp;
		}

		// overloading '=' operator here
		Complex operator = (Complex obj)
		{
			Complex temp;
			temp.real= real = obj.real;
			temp.img= img = obj.img;
			return temp;
		}

}; //end of complex class

int main()
{
	Complex c1(1,1),c2(5,20);
	Complex c3;
	c1.display();
	c2.display();
	c3.display();

	cout<< "The action starts here: "<<endl;

	//add 2 objects
	c3=c1+c2;
	//c3=c1.operator +(c2);	
	c3.display();

	c3=c1-c2;
	//c3=c1.operator -(c2);	
	c3.display();
	
	c3=c1*c2;
	//c3=c1.operator *(c2);	
	c3.display();

	c3=c1/c2;
	//c3=c1.operator /(c2);	
	c3.display();	

	c3=c1=c2;
	//c3=c1.operator /(c2);	
	c3.display();	

return 0;
}
