#include<iostream>
using namespace std;

class Complex
{

	
	public:
int real,img;	
	Complex() //default constructor
		{
		real=0;
		img=0;		
		}
		
		//parameter constructor
		Complex(int x, int y)
		{
		real=x;
		img=y;
		
		}
		
		void display()
		{
		cout<<"the real part is "<<real<<" and img part is "<<img<<endl<<endl;
		}


/*Complex operator = (Complex obj1)
		{
			obj1.real=real;
			obj1.img=img;
			return obj1;
		}
*/
friend Complex operator + (Complex obj1, Complex obj2);		

//friend Complex operator - (Complex obj1, Complex obj2);	

};



		// overloading '+' operator here
		Complex operator + (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real= obj1.real + obj2.real;
			temp.img= obj1.img + obj2.img;
			return temp;
		}

		// overloading '-' operator here
		Complex operator - (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real= obj1.real - obj2.real;
			temp.img= obj1.img - obj2.img;
			return temp;
		}

	
		// overloading '*' operator here
		Complex operator * (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real= obj1.real * obj2.real;
			temp.img= obj1.img * obj2.img;
			return temp;
		}

		// overloading '/' operator here
		Complex operator / (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real= obj1.real / obj2.real;
			temp.img= obj1.img / obj2.img;
			return temp;
		}

		
		// overloading '%' operator here
		Complex operator % (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real= obj1.real % obj2.real;
			temp.img= obj1.img % obj2.img;
			return temp;
		}


		/*Complex operator = (Complex obj1)
		{
			obj1.real=real;
			obj1.img=img;
			return obj1;
		}*/

		// overloading '>' operator here
		Complex operator > (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real=(obj1.real>obj2.real ? obj1.real : obj2.real); //prints larger par
			temp.img=(obj1.img>obj2.img ? obj1.img : obj2.img);

			return temp;
		}

		// overloading '<' operator here
		Complex operator < (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real=(obj1.real<obj2.real ? obj1.real : obj2.real); //prints smaller part
			temp.img=(obj1.img<obj2.img ? obj1.img : obj2.img);

			return temp;
		}

		// overloading '<=' operator here
		Complex operator <= (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real=(obj1.real<=obj2.real ? obj1.real : obj2.real); //prints smaller or equal part
			temp.img=(obj1.img<=obj2.img ? obj1.img : obj2.img);

			return temp;
		}

		// overloading '>=' operator here
		Complex operator >= (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real=(obj1.real>=obj2.real ? obj1.real : obj2.real); //prints greater or equal part
			temp.img=(obj1.img>=obj2.img ? obj1.img : obj2.img);

			return temp;
		}		

		// overloading '!=' operator here
		Complex operator != (Complex obj1, Complex obj2)
		{
			Complex temp;
			temp.real=(obj1.real!=obj2.real ? 0 : 1); //prints 1 if  equal and 0 if not
			temp.img=(obj1.img!=obj2.img ? 0 : 1);

			return temp;
		}


		// overloading '+=' operator here
		Complex operator += (Complex obj2)
		{
			Complex obj1;
			obj1.real+=real;
			obj1.img+=img; 	//error

			return obj1;
		}

		// overloading '-=' operator here
		Complex operator -= (Complex obj2)
		{
			Complex obj1;
			obj1.real-=real;
			obj1.img-=img; 	//error

			return obj1;
		}




int main()
{
Complex c1(10,1),c2(10,20);
	Complex c3;
	c1.display();
	c2.display();
	c3.display();

	cout<< "The action starts here: "<<endl;

	//add 2 objects
	c3=c1+c2;
	//c3=c1.operator +(c2);	
	c3.display();

	 c3=c1-c2;
	c3.display();
	
	c3=c1*c2;
	c3.display();

	c3=c1/c2;
	c3.display();	

	c3=c1%c2;
	c3.display();

	/*c1=c2;
	//c3=c1.operator /(c2);	
	c1.display();	
        */

	c3=c1>c2;
	c3.display();

	c3=c1<c2;
	c3.display();

	c3=c1<=c2;
	c3.display();
	
	c3=c1>=c2;
	c3.display();


	c3=c1!=c2;
	c3.display();

	
	c1+=c2; //error
	c1.display();
	
	c1-=c2; //error
	c1.display();


return 0;
}
