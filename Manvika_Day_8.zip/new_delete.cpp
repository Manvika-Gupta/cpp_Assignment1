#include<iostream>
using namespace std;

class A
{

	public:
int i,j; //size of each int variable is 4 bytes ---total =8
	A()
	{

	cout<<"Inside the constructor\n";
	i=0;
	j=10;
	}

	~A()
	{
	cout<<"Inside the destructor\n";
	}


};



int main()
{

//variable declaration

int *ptr1, *ptr2, sum; //size of any pointer is always 8 bytes.

//allocating memory using new

ptr1 =new int;
ptr2 =new int ;
//ptr3 =new int [5];


A a1;//*a2; //a2 is a pointer and not an object so constructor will not be called
//a2 = new A [5];
cout<<"Before the new operator in A\n";
//a2 = new A;
cout<<"Enter first number: ";
cin>> *ptr1;

cout<<"Enter second number: ";
cin>> *ptr2;

sum= *ptr1+*ptr2;
cout<<"\nSum of pointer variables = " <<sum<<endl;

//deleting pointer variables
delete ptr1;
delete ptr2;
//delete [] a2;

cout<<"All array objects and pointer variables are being deleted\n";

return 0;

}
