//Demonstrating single-level inheritance.

#include<iostream>
using namespace std;

class person{

public:
	void walk()
	{
	cout<<"Walk function called\n";
	}

       void talk()
	{
	cout<<"Talk function called\n";
	}
};

class doctor: public person
{
	public:

	void diagnose()
	{
	cout<<"Diagnose function called\n";
	}

};



int main()
{

person p;
doctor d;
d.walk();
d.talk();
d.diagnose();




return 0;
}
