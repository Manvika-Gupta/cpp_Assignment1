//Demonstrating multiple inheritance

#include<iostream>
using namespace std;


class liquid{

public:
	void liq()
	{
	cout<<"I am in liquid class\n";
	}



};

class fuel
{

public:
	void fue()
	{
	cout<<"I am in fuel class\n";
	}


};

class petrol: public liquid, public fuel
{

public:
	void pet()
	{
	cout<<"I am in petrol class\n";
	}


};

int main()
{
cout<<"--Calling from liquid class--\n";
liquid l;
l.liq();
cout<<"\n";
cout<<"--Calling from fuel class--\n";
fuel f;
f.fue();
cout<<"\n";
cout<<"--Calling from petrol class--\n";
petrol p;
p.liq();
p.fue();
p.pet();
return 0;
}



