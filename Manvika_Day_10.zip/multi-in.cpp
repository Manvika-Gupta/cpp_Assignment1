//Demonstrating multilevel inheritance

#include<iostream>
using namespace std;


class person{

public:
	void walk()
	{
	cout<<"Walk function invoked\n";
	}



};

class student: public person
{

public:
	void study()
	{
	cout<<"The student studies\n";
	}


};

class ITstudent: public student
{

public:
	void degree()
	{
	cout<<"The degree is BE Computer Engineering\n";
	}


};




int main()
{
cout<<"--Calling from person class--\n";
person p;
p.walk();
cout<<"\n";
cout<<"--Calling from student class--\n";
student st;
st.walk();
st.study();
cout<<"\n";
cout<<"--Calling from ITstudent class--\n";
ITstudent ist;
ist.walk();
ist.study();
ist.degree();




return 0;
}
