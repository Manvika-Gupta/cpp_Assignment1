//Demonstrating multiple inheritance

#include<iostream>
using namespace std;


class student{

public:
char name[30];
int roll;

  void basic_info()
	{
	cout<<"Enter roll no.\n";
	cin>>roll;
	cout<<"Enter the name\n";
	cin>>name;

	}

};

class test
{

public:
int marks[5];
	void marks_obtained()
	{
	cout<<"Enter marks obtained in the 5 subjects: ";
	for(int i=0;i<5;i++)
		{
		cin>>marks[i];
		}
	}

	

};

class result: public student, public test
{

public:
int sum=0;
float perc;
	void total_marks()
	{
cout<<endl;
	cout<<"Total marks obtained are:";
	for(int i=0;i<5;i++)
	{
	sum = sum + marks[i];
	}

	cout<<sum<<endl;
	}

	void percentage()
	{
	perc=((sum/500.0)*100.0);
	cout<<"The percentage obtained is: "<<perc<<endl;	
	}


};

int main()
{
//student s;
//s.basic_info();

//test t;
//t.marks_obtained();

result r;
r.basic_info();
r.marks_obtained();
r.total_marks();
r.percentage();


return 0;
}



